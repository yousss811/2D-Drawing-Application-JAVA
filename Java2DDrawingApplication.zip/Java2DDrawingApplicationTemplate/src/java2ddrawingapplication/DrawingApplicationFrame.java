/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java2ddrawingapplication;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Paint;
import java.awt.Point;
import java.awt.Stroke;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author acv
 */
public class DrawingApplicationFrame extends JFrame
{

    // Create the panels for the top of the application. One panel for each
    // line and one to contain both of those panels.
    private final JPanel topLineOptions = new JPanel(); 
    private final JPanel botLineOptions = new JPanel(); 
    private final JPanel optionsPanel = new JPanel();
    

    // create the widgets for the firstLine Panel.
    private final JButton undoButton = new JButton("Undo"); 
    private final JButton clearButton = new JButton("Clear"); 
    private final JLabel shapeText = new JLabel("Shape:"); 
    private final JComboBox shapeList = new JComboBox<>(new String[] { "Line", "Oval", "Rectangle" }); 
    private final JCheckBox filled = new JCheckBox("Filled"); 

    // create the widgets for the secondLine Panel.
    private final JCheckBox useGradient = new JCheckBox("Use Gradient"); 
    private final JButton firstColor = new JButton("1st Color..."); 
    private final JButton secondColor = new JButton("2nd Color...");
    private final JLabel lineWidthText = new JLabel("Line Width:");
    private final JTextField lineWidth = new JTextField("10",2); 
    private final JLabel dashLengthText = new JLabel("Dash Length:"); 
    private final JTextField dashLength = new JTextField("10",2);
    private final JCheckBox dashed = new JCheckBox("Dashed"); 

    // Variables for drawPanel.
    private Color colorOne = Color.BLACK; 
    private Color colorTwo = Color.WHITE;
    
    private int counter = 0; 
    private ArrayList<MyShapes> itemsDrawn = new ArrayList<>(); 
    private Paint paint; 
    private Stroke stroke;
    private float lineWidthFloat;
    private float dashedLengthFloat;
    
    private final DrawPanel drawPanel = new DrawPanel(); 
    

    // add status label
    private final JLabel mouseTracker = new JLabel("( , )");   
    // Constructor for DrawingApplicationFrame
    public DrawingApplicationFrame()
    {
        super("Java 2D Drawings"); 
        setLayout(new BorderLayout());
        // add widgets to panels
        // firstLine widgets
        topLineOptions.add(undoButton); 
        topLineOptions.add(clearButton); 
        topLineOptions.add(shapeText); 
        topLineOptions.add(shapeList); 
        topLineOptions.add(filled); 
        
        // secondLine widgets
        botLineOptions.add(useGradient); 
        botLineOptions.add(firstColor); 
        botLineOptions.add(secondColor); 
        botLineOptions.add(lineWidthText); 
        botLineOptions.add(lineWidth); 
        botLineOptions.add(dashLengthText);
        botLineOptions.add(dashLength);
        botLineOptions.add(dashed); 

        // add top panel of two panels
        optionsPanel.setLayout(new GridLayout(2,1));
        optionsPanel.add(topLineOptions);
        optionsPanel.add(botLineOptions);

        // add topPanel to North, drawPanel to Center, and statusLabel to South
        add(optionsPanel, BorderLayout.NORTH); 
        add(drawPanel, BorderLayout.CENTER);
        add(mouseTracker, BorderLayout.SOUTH); 
        
        //add listeners and event handlers
        
        
        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event){
            counter = 0; 
            itemsDrawn = new ArrayList<>();
            repaint();
            }
        });
        undoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event){
            counter -= 1; 
            itemsDrawn.remove(counter);
            repaint();
            }
        });
        firstColor.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {
                colorOne = JColorChooser.showDialog(null, "Choose a Color", Color.BLACK);
            }
        }); 
        secondColor.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {
                colorTwo = JColorChooser.showDialog(null, "Choose a Color", Color.BLACK);  
            }
        });    
        
    }

    // Create event handlers, if needed
    

    // Create a private inner class for the DrawPanel.
    private class DrawPanel extends JPanel
    {

        public DrawPanel()
        {
            MouseHandler m = new MouseHandler(); 
            addMouseListener(m); 
            addMouseMotionListener(m);
        }

        @Override
        public void paintComponent(Graphics g)
        {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;
            this.setBackground(Color.WHITE);
            

            //loop through and draw each shape in the shapes arraylist
            for(int count = 0; count < itemsDrawn.size(); count++){
                itemsDrawn.get(count).draw(g2d); 
            }
 
        }
        

        private class MouseHandler extends MouseAdapter implements MouseMotionListener
        {

            @Override
            public void mousePressed(MouseEvent event)
            {
                Point startPoint = new Point(event.getX(), event.getY());
                
                if(useGradient.isSelected()){
                    paint = new GradientPaint(5, 30, colorOne, 35, 100, colorTwo, true); 
                }
                else{
                    paint = colorOne; 
                }
                
                
                if(!dashLength.getText().isEmpty()){
                    dashedLengthFloat = Float.parseFloat(dashLength.getText()); 
                }
                else{
                    dashedLengthFloat = 10;
                }
                final float dash1[] = {dashedLengthFloat}; 
                if(!lineWidth.getText().isEmpty()){
                    lineWidthFloat = Float.parseFloat(lineWidth.getText());
                }
                else{
                    lineWidthFloat = 10;
                }
                
                
                if(dashed.isSelected()){
                    
                    stroke = new BasicStroke(lineWidthFloat, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 10, dash1, 0);
                }
                else{
                    stroke = new BasicStroke(lineWidthFloat, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);
                }
                
                
                
                if(shapeList.getSelectedItem() == "Rectangle"){
                    itemsDrawn.add(counter, new MyRectangle(startPoint, startPoint, paint, stroke, filled.isSelected()));
                } 
                else if(shapeList.getSelectedItem() == "Oval"){
                    itemsDrawn.add(counter, new MyOval(startPoint, startPoint, paint, stroke, filled.isSelected()));
                }
                else if(shapeList.getSelectedItem() == "Line"){
                    itemsDrawn.add(counter, new MyLine(startPoint, startPoint, paint, stroke));
                }
                counter += 1; 
                
                
                
                mouseTracker.setText(String.format("(%d, %d)", event.getX(), event.getY()));

            }

            @Override
            public void mouseReleased(MouseEvent event)
            {
            }

            @Override
            public void mouseDragged(MouseEvent event)
            {
                Point endPoint = new Point(event.getX(), event.getY()); 
                itemsDrawn.get(counter-1).setEndPoint(endPoint);
                repaint();
                
                mouseTracker.setText(String.format("(%d, %d)", event.getX(), event.getY()));
            }

            @Override
            public void mouseMoved(MouseEvent event)
            {
                mouseTracker.setText(String.format("(%d, %d)", event.getX(), event.getY()));
                
            }
        }

    }
}
